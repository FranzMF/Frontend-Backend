import img1 from '../../assets/images/item-cart-01.jpg'
import img2 from '../../assets/images/item-cart-02.jpg'
import img3 from '../../assets/images/item-cart-03.jpg'


export const cartItems = [
        { 
            id: 1, 
            name: "White Shirt Pleat",   
            price: "$19.00", 
            image: img1 

        },
        { 
            id: 2, 
            name: "Converse All Star",   
            price: "$39.00", 
            image: img2 

        },
        { 
            id: 3, 
            name: "Moon Porter Leather", 
            price: "$100.00", 
            image: img3
        },
        { 
            id: 4, 
            name: "Moon Porter Leather", 
            price: "$100.00", 
            image: img3
        },
        { 
            id: 5, 
            name: "Moon Porter Leather", 
            price: "$100.00", 
            image: img3
        }
    ];