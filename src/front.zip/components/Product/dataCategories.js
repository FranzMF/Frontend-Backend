
export const dataCategories = [
    {
        name: "Todos los productos", 
        filter: "*"
    },
    {
        name: "tecnologia", 
        filter: ".women"
    },
    {
        name: "Celulares", 
        filter: ".men"
    },
    {
        name: "Ropa", 
        filter: ".bag"
    },
    {
        name: "Consolas", 
        filter: ".shoes"
    },
    {
        name: "Tablets", 
        filter: ".watches"
    },
];